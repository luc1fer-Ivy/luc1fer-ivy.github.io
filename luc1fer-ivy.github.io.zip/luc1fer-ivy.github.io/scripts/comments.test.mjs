import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { loadComments, commentsSection } from './comments.mjs';

const source = await readFile(new URL('../assets/comments.js', import.meta.url), 'utf8');
const tick = () => new Promise(resolve => setImmediate(resolve));

async function widget({ readyConfig = true } = {}) {
  const handlers = {};
  const timers = new Map();
  let nextTimer = 0;
  let themeChange;
  let calls = 0;
  const state = { dataset: {}, hidden: false };
  const message = {};
  const retry = { hidden: true, addEventListener(name, callback) { handlers[name] = callback; } };
  const frames = [];
  const container = {
    children: [],
    replaceChildren() { this.children = []; frames.length = 0; },
    append(child) { this.children.push(child); },
    querySelector() { return frames[0] || null; }
  };
  const section = {
    dataset: { repo: 'luc1fer-Ivy/luc1fer-ivy.github.io', repoId: readyConfig ? 'repo123' : '', category: 'Announcements', categoryId: readyConfig ? 'cat123' : '', setupState: 'setup', term: 'post:melancholy-god' },
    querySelector(selector) { return ({ '[data-comments-state]': state, '[data-comments-message]': message, '[data-comments-retry]': retry, '.giscus': container })[selector]; }
  };
  const root = { dataset: { theme: 'light' } };
  const document = {
    documentElement: root,
    querySelector: () => section,
    createElement() { return { attributes: {}, setAttribute(name, value) { this.attributes[name] = value; } }; }
  };
  const context = {
    document, window: { addEventListener(name, callback) { handlers[name] = callback; } },
    MutationObserver: class { constructor(callback) { themeChange = callback; } observe() {} },
    AbortController, encodeURIComponent,
    setTimeout(callback) { timers.set(++nextTimer, callback); return nextTimer; },
    clearTimeout(id) { timers.delete(id); },
    async fetch() { calls++; throw new Error('Visitors must not fetch the configuration API'); }
  };
  vm.runInNewContext(source, context);
  await tick();
  return { state, message, retry, handlers, container, root, timers, calls: () => calls,
    themeChange: () => themeChange(),
    addFrame() {
      const posts = [];
      const frame = { contentWindow: { postMessage: (...args) => posts.push(args) }, posts };
      frames.push(frame);
      return frame;
    }
  };
}

test('GitHub widget enables real reactions, Chinese login UI, and stable article mapping', async () => {
  const w = await widget();
  const script = w.container.children[0];
  assert.equal(script.src, 'https://giscus.app/client.js');
  assert.equal(script.attributes['data-reactions-enabled'], '1');
  assert.equal(script.attributes['data-term'], 'post:melancholy-god');
  assert.equal(script.attributes['data-mapping'], 'specific');
  assert.equal(script.attributes['data-strict'], '1');
  assert.equal(script.attributes['data-category-id'], 'cat123');
  assert.equal(script.attributes['data-lang'], 'zh-CN');
});

test('missing installation gives an honest setup state without browser API calls', async () => {
  const w = await widget({ readyConfig: false });
  assert.equal(w.state.dataset.state, 'setup');
  assert.match(w.message.textContent, /正在开通/);
  assert.equal(w.retry.hidden, true);
  assert.equal(w.container.children.length, 0);
  assert.equal(w.calls(), 0);
});

test('only the exact giscus iframe can change connection status', async () => {
  const w = await widget({ readyConfig: true });
  const frame = w.addFrame();
  w.handlers.message({ origin: 'https://evil.example', source: frame.contentWindow, data: { giscus: { resizeHeight: 500 } } });
  assert.equal(w.state.hidden, false);
  w.handlers.message({ origin: 'https://giscus.app', source: {}, data: { giscus: { resizeHeight: 500 } } });
  assert.equal(w.state.hidden, false);
  w.handlers.message({ origin: 'https://giscus.app', source: frame.contentWindow, data: { giscus: { resizeHeight: 500 } } });
  assert.equal(w.state.hidden, true);
  assert.equal(w.calls(), 0);
  assert.equal(frame.posts.length, 1);
  w.handlers.message({ origin: 'https://giscus.app', source: frame.contentWindow, data: { giscus: { resizeHeight: 501 } } });
  assert.equal(frame.posts.length, 1, 'resize must not cause a theme message loop');
  w.root.dataset.theme = 'dark';
  w.themeChange();
  assert.equal(frame.posts.at(-1)[0].giscus.setConfig.theme, 'dark_dimmed');
  assert.equal(frame.posts.at(-1)[1], 'https://giscus.app');
});

test('a new article with no discussion yet is not treated as an API failure', async () => {
  const w = await widget({ readyConfig: true });
  const frame = w.addFrame();
  w.handlers.message({ origin: 'https://giscus.app', source: frame.contentWindow, data: { giscus: { error: 'Discussion not found' } } });
  assert.notEqual(w.state.dataset.state, 'error');
});

test('config can disable comments and rejects malformed repository names', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'blog-comments-'));
  try {
    await writeFile(path.join(dir, 'comments.json'), '{"enabled":false}');
    assert.equal((await loadComments(dir)).enabled, false);
    assert.equal(commentsSection('article', { enabled: false }, String), '');
    await writeFile(path.join(dir, 'comments.json'), '{"enabled":true,"repo":"javascript:alert(1)"}');
    await assert.rejects(loadComments(dir), /repo 必须/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});


test('build resolves public IDs and handles missing installation or category', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'blog-giscus-build-'));
  try {
    await writeFile(path.join(dir, 'comments.json'), JSON.stringify({ enabled: true, repo: 'luc1fer-Ivy/luc1fer-ivy.github.io', category: 'Announcements' }));
    const good = await loadComments(dir, async () => ({ ok: true, status: 200, json: async () => ({ repositoryId: 'R_repo123', categories: [{ id: 'DIC_cat123', name: 'Announcements' }] }) }));
    assert.equal(good.ready, true);
    assert.equal(good.categoryId, 'DIC_cat123');
    const notInstalled = await loadComments(dir, async () => ({ ok: false, status: 403 }));
    assert.equal(notInstalled.setupState, 'setup');
    const noCategory = await loadComments(dir, async () => ({ ok: true, status: 200, json: async () => ({ repositoryId: 'R_repo123', categories: [{ id: 'DIC_general', name: 'General' }] }) }));
    assert.equal(noCategory.ready, false);
    assert.equal(noCategory.categoryId, undefined);
    const offline = await loadComments(dir, async () => { throw new Error('offline'); });
    assert.equal(offline.ready, false);
    assert.equal(offline.setupState, 'unavailable');
  } finally { await rm(dir, { recursive: true, force: true }); }
});
