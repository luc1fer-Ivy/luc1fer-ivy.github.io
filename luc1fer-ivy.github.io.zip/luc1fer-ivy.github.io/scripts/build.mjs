import { readFile, writeFile, mkdir, readdir, rm, cp } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { marked } from '../vendor/marked.mjs';
import { loadComments, commentsSection } from './comments.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'dist');
const config = JSON.parse(await readFile(path.join(root, 'site.json'), 'utf8'));
const comments = await loadComments(root);
const base = (process.env.SITE_BASE ?? config.baseurl ?? '').replace(/\/$/, '');
if (base && !/^\/[A-Za-z0-9_\-/]+$/.test(base)) throw new Error('SITE_BASE 必须是以 / 开头的安全路径。');
const origin = (process.env.SITE_URL ?? config.url ?? '').replace(/\/$/, '');
if (origin && !/^https?:\/\/[^\s]+$/.test(origin)) throw new Error('SITE_URL 必须是完整的 http(s) 网址。');
const href = (p = '') => `${base}/${p.replace(/^\//, '')}`;
const absolute = (p = '') => origin ? `${origin}${href(p)}` : href(p);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
const icons = {
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  moon: '<path d="M20.5 13A8.5 8.5 0 0 1 11 3.5 8.5 8.5 0 1 0 20.5 13Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  back: '<path d="M19 12H5m6-6-6 6 6 6"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  rss: '<circle cx="5" cy="19" r="1"/><path d="M4 11a9 9 0 0 1 9 9M4 4a16 16 0 0 1 16 16"/>',
  link: '<path d="m10 13 4-4m-6 7-1 1a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m0 2 1-1a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(1 1)"/>',
  github: '<path d="M9 19c-4 1-4-2-5-2m10 5v-4a3.5 3.5 0 0 0-1-3c3-.3 6-1.5 6-6A4.7 4.7 0 0 0 18 6a4.3 4.3 0 0 0-.1-3S16.7 2.7 14 4a11.5 11.5 0 0 0-6 0C5.3 2.7 4.1 3 4.1 3A4.3 4.3 0 0 0 4 6a4.7 4.7 0 0 0-1 3c0 4.5 3 5.7 6 6a3.5 3.5 0 0 0-1 3v4"/>'
};
const icon = (name, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]}</svg>`;

function frontMatter(raw, filename) {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
  if (!match) throw new Error(`${filename}: 缺少文章开头的 --- 配置。`);
  const data = {};
  for (const line of match[1].split(/\r?\n/)) {
    if (!line.trim() || line.trimStart().startsWith('#')) continue;
    const item = line.match(/^([a-z_]+):\s*(.*?)\s*$/);
    if (!item) throw new Error(`${filename}: 不支持的配置行：${line}`);
    const value = item[2];
    if (/^(?:true|false|\[|"|\d+$)/.test(value)) {
      try { data[item[1]] = JSON.parse(value); }
      catch { data[item[1]] = value.replace(/^['"]|['"]$/g, ''); }
    } else data[item[1]] = value.replace(/^['"]|['"]$/g, '');
  }
  return { data, markdown: match[2] };
}

const posts = [];
const sourceFiles = (await readdir(path.join(root, '_posts'))).filter(f => f.endsWith('.md')).sort();
for (const file of sourceFiles) {
  const name = file.match(/^(\d{4}-\d{2}-\d{2})-([a-z0-9][a-z0-9-]*)\.md$/);
  if (!name) throw new Error(`文章名称必须是 YYYY-MM-DD-英文短名.md：${file}`);
  const { data, markdown } = frontMatter(await readFile(path.join(root, '_posts', file), 'utf8'), file);
  if (data.draft === true) continue;
  if (!data.title || !data.description || !Array.isArray(data.tags)) throw new Error(`${file}: title、description 和 tags 是必填项。`);
  const date = String(data.date || name[1]);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date))) throw new Error(`${file}: 日期格式不正确。`);
  const slug = name[2];
  if (posts.some(p => p.slug === slug)) throw new Error(`重复的文章链接：${slug}`);
  let html = marked.parse(markdown, { gfm: true });
  const headings = [];
  html = html.replace(/<h([23])>([\s\S]*?)<\/h\1>/g, (_, level, content) => {
    const id = `section-${headings.length + 1}`;
    const title = content.replace(/<[^>]*>/g, '');
    headings.push({ id, level: Number(level), title });
    return `<h${level} id="${id}">${content}<a class="heading-anchor" href="#${id}" aria-label="此段落的链接">#</a></h${level}>`;
  });
  html = html.replace(/(src|href)="\/(?!\/)([^"]*)"/g, (_, attr, p) => `${attr}="${esc(href(p))}"`);
  const words = markdown.replace(/---[\s\S]*?---/g, '').replace(/[#*`>\[\]()]/g, '').length;
  posts.push({ ...data, date, slug, markdown, html, headings, minutes: Math.max(1, Math.ceil(words / 450)), url: href(`posts/${slug}/`) });
}
posts.sort((a, b) => b.date.localeCompare(a.date) || a.slug.localeCompare(b.slug));
const ordered = [...posts].sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.date.localeCompare(a.date) || a.slug.localeCompare(b.slug));
const tags = [...new Set(posts.flatMap(p => p.tags))].sort();
const dateLabel = d => `${Number(d.slice(5, 7))} 月 ${Number(d.slice(8, 10))} 日`;
const year = new Date().getUTCFullYear();

function layout({ title, description = config.description, page = 'home', content, pathname = '', article = null }) {
  const fullTitle = title ? `${title} · ${config.title}` : config.title;
  const canonical = origin ? `<link rel="canonical" href="${esc(absolute(pathname))}"><meta property="og:url" content="${esc(absolute(pathname))}">` : '';
  const contact = config.github ? `<a href="https://github.com/${encodeURIComponent(config.github)}" rel="me" aria-label="GitHub">${icon('github')}</a>` : '';
  const metadata = article ? `<meta property="article:published_time" content="${article.date}T00:00:00+08:00">` : '';
  return `<!DOCTYPE html>
<html lang="${esc(config.language)}" data-base="${esc(base)}">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark"><title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description)}"><meta name="author" content="${esc(config.author)}">
<meta property="og:title" content="${esc(fullTitle)}"><meta property="og:description" content="${esc(description)}"><meta property="og:type" content="${article ? 'article' : 'website'}"><meta property="og:locale" content="zh_CN">${metadata}${canonical}
<link rel="icon" href="${href('assets/favicon.svg')}" type="image/svg+xml">
<link rel="alternate" type="application/rss+xml" title="${esc(config.title)}" href="${href('feed.xml')}">
<script>try{const t=localStorage.getItem('jason-theme');document.documentElement.dataset.theme=t||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch{}</script>
<link rel="stylesheet" href="${href('assets/style.css')}">
<script defer src="${href('assets/app.js')}"></script>
${article && comments.enabled ? `<link rel="stylesheet" href="${href('assets/comments.css')}"><script defer src="${href('assets/comments.js')}"></script><meta name="giscus:backlink" content="${esc(absolute(pathname))}">` : ''}
</head>
<body class="page-${page}">
<a class="skip-link" href="#main">跳到正文</a>
<div class="reading-progress" aria-hidden="true"><span></span></div>
<header class="site-header"><div class="header-inner">
<a class="wordmark" href="${href()}">${esc(config.title)}<span class="brand-dot">.</span></a>
<nav class="nav" aria-label="主导航"><a href="${href()}" ${page === 'home' || page === 'post' ? 'aria-current="page"' : ''}>文章</a><a href="${href('archive/')}" ${page === 'archive' ? 'aria-current="page"' : ''}>归档</a><a href="${href('about/')}" ${page === 'about' ? 'aria-current="page"' : ''}>关于</a></nav>
<div class="header-actions"><button class="icon-button" type="button" data-search-open aria-label="搜索文章" title="搜索文章 /">${icon('search')}</button><button class="icon-button theme-button" type="button" data-theme-toggle aria-label="切换深色模式" title="切换明暗模式">${icon('moon', 'moon')}${icon('sun', 'sun')}</button></div>
</div></header>
<main id="main" class="main ${page === 'post' ? 'main-article' : ''}">${content}</main>
<footer class="site-footer"><div class="footer-inner"><p>© ${year} ${esc(config.author)}<span class="footer-dot">·</span>写下此刻，留给以后。</p><div class="footer-links">${contact}<a href="${href('feed.xml')}" aria-label="订阅 RSS" title="订阅 RSS">${icon('rss')}</a><a class="back-top" href="#main">回到顶部 ↑</a></div></div></footer>
<dialog class="search-dialog" aria-labelledby="search-title"><div class="search-heading"><h2 id="search-title">找一篇文章</h2><button class="icon-button" type="button" data-search-close aria-label="关闭搜索">${icon('close')}</button></div><div class="search-input-wrap">${icon('search')}<input id="search-input" type="search" autocomplete="off" placeholder="输入标题、关键词或标签…" aria-label="搜索文章"><kbd>ESC</kbd></div><p class="search-status" aria-live="polite"></p><div class="search-results"></div></dialog>
<div class="toast" role="status" aria-live="polite"></div>
</body></html>`;
}
function tagMarkup(p) { return p.tags.map(t => `<span class="tag">${esc(t)}</span>`).join(''); }
function postRow(p, index) {
  return `<article class="post-row" data-post data-tags="${esc(JSON.stringify(p.tags))}" style="--order:${index}"><div class="post-date"><span>${p.date.slice(5).replace('-', '.')}</span><span>${p.date.slice(0, 4)}</span></div><div class="post-summary"><div class="post-meta">${tagMarkup(p)}${p.pinned ? '<span class="pinned">置顶</span>' : ''}${p.sample ? '<span class="sample-label">示例</span>' : ''}</div><h2><a href="${p.url}">${esc(p.title)}</a></h2><p>${esc(p.description)}</p><a class="read-more" href="${p.url}" aria-label="阅读全文：${esc(p.title)}">阅读全文 ${icon('arrow')}<span>${p.minutes} 分钟</span></a></div></article>`;
}
const home = `<section class="intro"><p class="eyebrow"><span></span> A PERSONAL JOURNAL</p><h1>${esc(config.headline)}</h1><p class="intro-description">${esc(config.description)}</p><div class="intro-signature"><span class="signature-line"></span><span>${esc(config.author)}</span></div></section>
<section class="journal-section" aria-labelledby="journal-heading"><div class="section-heading"><h2 id="journal-heading">最近的记录<span class="post-total">${posts.length.toString().padStart(2, '0')}</span></h2><a href="${href('archive/')}" class="archive-link">所有文章 ${icon('arrow')}</a></div><div class="tag-filters" role="group" aria-label="按主题筛选"><button type="button" data-filter="all" aria-pressed="true">全部<span>${posts.length}</span></button>${tags.map(t => `<button type="button" data-filter="${esc(t)}" aria-pressed="false">${esc(t)}<span>${posts.filter(p => p.tags.includes(t)).length}</span></button>`).join('')}</div><div class="posts">${ordered.map(postRow).join('') || '<p class="empty-note">第一篇文章，还在路上。</p>'}</div><div class="filter-empty" hidden>这个主题暂时没有文章。</div><p class="list-end"><span></span>未完，待续<span></span></p></section>`;

const groups = new Map();
for (const p of posts) { const y = p.date.slice(0, 4); if (!groups.has(y)) groups.set(y, []); groups.get(y).push(p); }
const archive = `<section class="page-intro"><p class="eyebrow">THE ARCHIVE</p><h1>写过的，都在这里。</h1><p>共 ${posts.length} 篇文章，慢慢积累。</p></section><div class="archive">${[...groups.entries()].map(([y, list]) => `<section class="archive-year"><h2>${y}<span>${list.length} 篇</span></h2><ol>${list.map(p => `<li><time datetime="${p.date}">${p.date.slice(5).replace('-', '.')}</time><a href="${p.url}">${esc(p.title)}${icon('arrow')}</a></li>`).join('')}</ol></section>`).join('') || '<p class="empty-note">这里将收录每一篇文章。</p>'}</div>`;
const about = `<section class="page-intro"><p class="eyebrow">A LITTLE ABOUT ME</p><h1>你好，我是 ${esc(config.author)}。</h1><p>很高兴在这里遇见你。</p></section><div class="about-content prose"><p class="about-lead">给想法一点空间，<br>给日常一点耐心。</p><p>这里是我的个人博客，用来记录学习中的问题、摄影里的观察，以及生活中值得留下的片刻。</p><h2>关于这个小站</h2><p>有些文章是整理过的笔记，有些只是正在生长的想法。把它们写下来，是为了看得更清楚，也为了以后能够回头翻一翻。</p><div class="interests"><span>学习与思考</span><span>摄影与观察</span><span>生活与记录</span></div><h2>慢慢写，慢慢来</h2><p>这个小站刚刚开始。希望每一次记录，都比上一次多一点具体，少一点匆忙。</p>${config.email ? `<p>可以通过 <a href="mailto:${esc(config.email)}">${esc(config.email)}</a> 联系我。</p>` : ''}<a class="text-link" href="${href()}">去看看文章 ${icon('arrow')}</a></div>`;

await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
await cp(path.join(root, 'assets'), path.join(out, 'assets'), { recursive: true });
async function save(p, html) { const dest = path.join(out, p); await mkdir(path.dirname(dest), { recursive: true }); await writeFile(dest, html); }
await save('index.html', layout({ content: home }));
await save('archive/index.html', layout({ title: '归档', page: 'archive', content: archive, pathname: 'archive/' }));
await save('about/index.html', layout({ title: '关于', page: 'about', content: about, pathname: 'about/' }));
for (let i = 0; i < posts.length; i++) {
  const p = posts[i];
  const previous = posts[i - 1]; const next = posts[i + 1];
  const related = posts.filter(q => q.slug !== p.slug).slice(0, 2);
  const toc = p.headings.length ? `<aside class="toc" aria-label="文章目录"><p>本文目录</p><ol>${p.headings.map(h => `<li class="toc-level-${h.level}"><a href="#${h.id}">${h.title}</a></li>`).join('')}</ol><a class="toc-top" href="#main">回到顶部 ↑</a></aside>` : '';
  const content = `<a class="back-link" href="${href()}">${icon('back')} 所有文章</a><header class="article-header"><div class="post-meta">${tagMarkup(p)}${p.sample ? '<span class="sample-label">示例文章</span>' : ''}</div><h1>${esc(p.title)}</h1><p class="article-description">${esc(p.description)}</p><div class="article-byline"><span>${esc(config.author)}</span><span>·</span><time datetime="${p.date}">${p.date.slice(0, 4)} 年 ${dateLabel(p.date)}</time><span>·</span><span>阅读约 ${p.minutes} 分钟</span>${comments.enabled ? '<a class="article-talk" href="#comments">评论与点赞 ↓</a>' : ''}</div></header><div class="article-grid"><div><article class="prose">${p.sample ? '<div class="sample-note">这是一篇示例文章，用于展示博客的排版与阅读体验。</div>' : ''}${p.html}</article><div class="article-end"><span>— 完 —</span><button class="copy-link" type="button" data-copy-link>${icon('link')} 复制文章链接</button></div>${commentsSection(p.slug, comments, esc)}<nav class="post-navigation" aria-label="相邻文章">${previous ? `<a href="${previous.url}"><span>上一篇</span>${esc(previous.title)}</a>` : '<div></div>'}${next ? `<a href="${next.url}"><span>下一篇</span>${esc(next.title)}</a>` : '<div></div>'}</nav>${related.length ? `<section class="related"><h2>也许你还想读</h2>${related.map(q => `<a href="${q.url}">${esc(q.title)}${icon('arrow')}</a>`).join('')}</section>` : ''}</div>${toc}</div>`;
  await save(`posts/${p.slug}/index.html`, layout({ title: p.title, description: p.description, page: 'post', content, pathname: `posts/${p.slug}/`, article: p }));
}
await save('404.html', layout({ title: '页面未找到', page: 'notfound', content: `<section class="not-found"><p class="eyebrow">404 / A SMALL DETOUR</p><h1>这一页，走丢了。</h1><p>可能是链接变了，也可能这篇文章还没有写完。</p><a class="text-link" href="${href()}">回到首页 ${icon('arrow')}</a></section>` }));
await save('search.json', JSON.stringify(posts.map(({ title, description, tags, url, date, markdown }) => ({ title, description, tags, url, date, text: markdown.replace(/[#*`>]/g, '') }))));
const feed = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>${esc(config.title)}</title><link>${esc(absolute())}</link><description>${esc(config.description)}</description><language>zh-CN</language>${posts.map(p => `<item><title>${esc(p.title)}</title><link>${esc(absolute(`posts/${p.slug}/`))}</link><guid isPermaLink="${origin ? 'true' : 'false'}">${esc(absolute(`posts/${p.slug}/`))}</guid><description>${esc(p.description)}</description><pubDate>${new Date(`${p.date}T00:00:00+08:00`).toUTCString()}</pubDate></item>`).join('')}</channel></rss>`;
await save('feed.xml', feed);
await save('.nojekyll', '');
if (origin) {
  await save('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${['', 'archive/', 'about/', ...posts.map(p => `posts/${p.slug}/`)].map(p => `<url><loc>${esc(absolute(p))}</loc></url>`).join('')}</urlset>`);
  await save('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${absolute('sitemap.xml')}\n`);
}
console.log(`Built ${posts.length} posts, home, archive, about and 404. Base path: ${base || '/'}.`);
