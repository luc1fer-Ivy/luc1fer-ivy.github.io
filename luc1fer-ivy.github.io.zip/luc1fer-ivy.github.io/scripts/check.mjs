import { readdir, readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
async function files(dir) { const result = []; for (const f of await readdir(dir, { withFileTypes: true })) { const p = path.join(dir, f.name); if (f.isDirectory()) result.push(...await files(p)); else result.push(p); } return result; }
const htmlFiles = (await files(root)).filter(f => f.endsWith('.html'));
const errors = [];
for (const f of htmlFiles) {
  const html = await readFile(f, 'utf8');
  const base = html.match(/data-base="([^"]*)"/)?.[1] || '';
  for (const [, target] of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    if (/^(https?:|mailto:|data:|#)/.test(target)) continue;
    let cleaned = target.split(/[?#]/)[0];
    if (base && cleaned.startsWith(base + '/')) cleaned = cleaned.slice(base.length);
    let local = path.join(root, cleaned.replace(/^\//, ''));
    try { if ((await stat(local)).isDirectory()) local = path.join(local, 'index.html'); await stat(local); }
    catch { errors.push(`${path.relative(root, f)}: missing ${target}`); }
  }
  for (const [, id] of html.matchAll(/href="#([^"]+)"/g)) {
    if (!html.includes(`id="${id}"`)) errors.push(`${path.relative(root, f)}: missing anchor #${id}`);
  }
  if (!html.includes('<title>') || !html.includes('name="description"')) errors.push(`Missing metadata: ${f}`);
}
if (errors.length) { console.error(errors.join('\n')); process.exit(1); }
console.log(`Checked ${htmlFiles.length} pages: links, anchors and metadata passed.`);
