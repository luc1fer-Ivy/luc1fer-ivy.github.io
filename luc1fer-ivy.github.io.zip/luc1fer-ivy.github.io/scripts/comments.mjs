import { readFile } from 'node:fs/promises';
import path from 'node:path';

export async function loadComments(root, fetcher = globalThis.fetch) {
  let config;
  try { config = JSON.parse(await readFile(path.join(root, 'comments.json'), 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return { enabled: false }; throw error; }
  if (typeof config.enabled !== 'boolean') throw new Error('comments.json: enabled 必须为 true 或 false。');
  if (!config.enabled) return config;
  if (!/^[a-z\d][a-z\d-]*\/[a-z\d_.-]+$/i.test(config.repo || '')) throw new Error('comments.json: repo 必须为 用户名/仓库名。');
  for (const key of ['repoId', 'categoryId']) {
    if (config[key] && !/^[\w=+-]{1,160}$/.test(config[key])) throw new Error(`comments.json: ${key} 格式不正确。`);
  }
  if (typeof config.category !== 'string' || !config.category.trim()) throw new Error('comments.json: 请填写 category。');
  if (config.repoId && config.categoryId) return { ...config, ready: true };
  // Resolve public IDs during the build. Giscus's configuration API is not
  // available to arbitrary browser origins, so visitors never fetch it directly.
  try {
    const response = await fetcher(`https://giscus.app/api/discussions/categories?repo=${encodeURIComponent(config.repo)}`, {
      headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(6000)
    });
    if (response.status === 403) return { ...config, ready: false, setupState: 'setup' };
    if (!response.ok) throw new Error('Giscus configuration unavailable');
    const data = await response.json();
    const category = data.categories?.find(item => item.name === config.category);
    if (!data.repositoryId || !category?.id) return { ...config, ready: false, setupState: 'setup' };
    if (![data.repositoryId, category.id].every(id => typeof id === 'string' && /^[\w=+-]{1,160}$/.test(id))) throw new Error('Invalid public IDs');
    return { ...config, repoId: data.repositoryId, categoryId: category.id, ready: true };
  } catch {
    console.warn('评论配置暂未连通；文章照常生成。开通后重新运行构建，或在 comments.json 填写公开 ID。');
    return { ...config, ready: false, setupState: 'unavailable' };
  }
}

export function commentsSection(slug, config, esc) {
  if (!config.enabled) return '';
  return `<section id="comments" class="comments-section" aria-labelledby="comments-title" data-comments data-repo="${esc(config.repo)}" data-repo-id="${esc(config.repoId || '')}" data-category="${esc(config.category)}" data-category-id="${esc(config.categoryId || '')}" data-setup-state="${esc(config.setupState || '')}" data-term="post:${esc(slug)}">
<div class="comments-heading"><div><p class="eyebrow">THE CONVERSATION</p><h2 id="comments-title">留一句话，也留个喜欢。</h2></div><span class="comments-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M8 10h8M8 14h5M20 12a8 8 0 0 1-8 8H4l1.4-4.1A8 8 0 1 1 20 12Z"/></svg>评论与点赞</span></div>
<p class="comments-intro">用 GitHub 登录，和我聊聊这篇文章。点击下方的 👍，也可以留下一个喜欢。</p>
<div class="comments-state" data-comments-state role="status" aria-live="polite"><span class="comments-status-dot" aria-hidden="true"></span><span data-comments-message>正在连接评论区…</span><button type="button" class="comments-retry" data-comments-retry hidden>重试</button></div>
<div class="giscus" aria-label="GitHub 评论和点赞"></div>
<div class="comments-footer"><span>评论与点赞保存在 GitHub Discussions。</span><a href="https://github.com/${esc(config.repo)}/discussions" target="_blank" rel="noopener noreferrer">在 GitHub 查看 ↗</a></div>
<noscript><p class="comments-noscript">请启用 JavaScript 加载评论，或使用上方链接前往 GitHub 讨论区。</p></noscript>
</section>`;
}
