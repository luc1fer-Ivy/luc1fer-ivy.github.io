---
title: "忧郁的神"
description: "车窗边的一帧。"
tags: ["摄影"]
sample: false
pinned: true
---

![忧郁的神](/assets/images/melancholy-god.jpg)
