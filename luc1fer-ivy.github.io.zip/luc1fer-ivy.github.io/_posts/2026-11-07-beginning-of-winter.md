---
title: "立冬之日"
description: "高三的周六傍晚，五个人、两小时空隙和一锅热汤。"
tags: ["随笔", "生活"]
sample: false
pinned: true
---

这是一个高三的周六傍晚。趁着这两个小时的空隙，跑到牛肉馆吃牛鞭汤去了。

起初只有我和 dudu 去，然后在我的盛情邀请之下，猪咪、骷髅、国一都加入了我们的队伍。

打车的时候，不出意外，车坐不下，只能坐四个人。没办法，他们都没手机，那只能让他们先过去，我就接着打车。

我就在想，是不是我骑电动车更快？因为要考虑打车拥堵的时间，我发现骑电动车是最优解，就跑到了新村，骑上电动车前往牛肉馆。

不出意外，我先到了，一人在风中凌乱。他们到的时候还很震惊：怎么会这么快？（hhhh，现在解密了，不知道他们会不会看到这篇 blog。）

接着就开始点菜了。直接上了一大锅牛鞭汤，还有一些牛杂、牛百叶。当然，觉得这汤太猛，怕自己顶不住，我又点了份牛肉汤。以下是菜单：

<img src="/assets/images/beginning-of-winter/menu.png" alt="当晚的菜单与订单，小计 410 元" width="1179" height="2556" loading="lazy" decoding="async" style="width:100%;max-width:420px;">

五个人，四百来块，吃得还是绰绰有余的。期间吃饭的时候，dudu 开的玩笑害我差点把饭喷出来了：）

以下是照片：

<img src="/assets/images/beginning-of-winter/friends.jpg" alt="五个人在牛肉馆的合照" width="1536" height="1152" loading="lazy" decoding="async">

<img src="/assets/images/beginning-of-winter/dinner.jpg" alt="围着一锅热汤，开始吃饭" width="1536" height="1152" loading="lazy" decoding="async">

三下五除二就给炫完了。在等车时，还企盼着头上能有飞机飞过，因为旁边就是机场，降落时非常震撼。结果他们一上车，飞机就过来了，真的超级大、超级震撼！然后就回到了学校。

最后引 dudu 的一句话：

> 别人的高三，刷题；我们的高三，牛鞭。

哈哈哈哈，就这样，the end。
