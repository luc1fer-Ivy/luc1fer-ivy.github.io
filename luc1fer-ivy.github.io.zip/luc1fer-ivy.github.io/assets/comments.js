(() => {
  'use strict';
  const section = document.querySelector('[data-comments]');
  if (!section) return;
  const host = 'https://giscus.app';
  const state = section.querySelector('[data-comments-state]');
  const message = section.querySelector('[data-comments-message]');
  const retry = section.querySelector('[data-comments-retry]');
  const container = section.querySelector('.giscus');
  let busy = false;
  let loaded = false;
  let timeout;
  const theme = () => document.documentElement.dataset.theme === 'dark' ? 'dark_dimmed' : 'light';
  const status = (text, mode = 'loading') => {
    state.hidden = !text;
    state.dataset.state = mode;
    message.textContent = text;
    retry.hidden = mode === 'loading';
  };

  if (!section.dataset.repoId || !section.dataset.categoryId) {
    status(section.dataset.setupState === 'setup'
      ? '评论与点赞正在开通，稍后就能在这里参与讨论。'
      : '评论暂时不可用，可以先前往 GitHub 查看。', 'setup');
    retry.hidden = true;
    return;
  }

  async function connect() {
    if (busy || loaded) return;
    busy = true;
    clearTimeout(timeout);
    status('正在连接评论区…');
    container.replaceChildren();
    try {
      const config = section.dataset;
      const script = document.createElement('script');
      script.src = `${host}/client.js`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      const attributes = {
        repo: section.dataset.repo, 'repo-id': config.repoId,
        category: config.category, 'category-id': config.categoryId,
        mapping: 'specific', term: section.dataset.term, strict: '1',
        'reactions-enabled': '1', 'emit-metadata': '1',
        'input-position': 'top', theme: theme(), lang: 'zh-CN', loading: 'eager'
      };
      for (const [key, value] of Object.entries(attributes)) script.setAttribute(`data-${key}`, value);
      script.onerror = () => {
        busy = false;
        clearTimeout(timeout);
        status('评论暂时无法连接。请重试，或前往 GitHub 查看。', 'error');
      };
      container.append(script);
      // Giscus sends its iframe resize message when the UI is ready.
      timeout = setTimeout(() => {
        busy = false;
        if (!loaded) status('评论加载较慢。请重试，或前往 GitHub 查看。', 'error');
      }, 20000);
    } catch (error) {
      busy = false;
      status(error.message === 'setup'
        ? '评论与点赞正在开通，稍后就能在这里参与讨论。'
        : '评论暂时无法连接。请重试，或前往 GitHub 查看。',
        error.message === 'setup' ? 'setup' : 'error');
    }
  }

  window.addEventListener('message', event => {
    const frame = container.querySelector('iframe.giscus-frame');
    if (event.origin !== host || !frame || event.source !== frame.contentWindow) return;
    const data = event.data?.giscus;
    if (!data || typeof data !== 'object') return;
    if (typeof data.error === 'string' && !data.error.includes('Discussion not found')) {
      busy = false;
      loaded = false;
      clearTimeout(timeout);
      status('评论暂时不可用。请重试，或前往 GitHub 查看。', 'error');
    } else if ((typeof data.resizeHeight === 'number' || typeof data.resizeHeight === 'string') &&
      Number.isFinite(Number(data.resizeHeight)) && Number(data.resizeHeight) > 0) {
      const firstLoad = !loaded;
      busy = false;
      loaded = true;
      clearTimeout(timeout);
      status('');
      // Apply the latest theme even if it changed during iframe startup.
      if (firstLoad) frame.contentWindow.postMessage({ giscus: { setConfig: { theme: theme() } } }, host);
    }
  });
  new MutationObserver(() => {
    container.querySelector('iframe.giscus-frame')?.contentWindow?.postMessage(
      { giscus: { setConfig: { theme: theme() } } }, host
    );
  }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  retry.addEventListener('click', connect);
  connect();
})();
