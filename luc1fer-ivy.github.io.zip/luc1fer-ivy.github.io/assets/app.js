(() => {
  const root = document.documentElement;
  const base = root.dataset.base || '';
  const toggle = document.querySelector('[data-theme-toggle]');
  const media = matchMedia('(prefers-color-scheme: dark)');
  function storedTheme() { try { return localStorage.getItem('jason-theme'); } catch { return null; } }
  function setTheme(theme, persist = false) {
    root.dataset.theme = theme;
    toggle?.setAttribute('aria-label', theme === 'dark' ? '切换浅色模式' : '切换深色模式');
    toggle?.setAttribute('aria-pressed', String(theme === 'dark'));
    if (persist) { try { localStorage.setItem('jason-theme', theme); } catch {} }
  }
  setTheme(root.dataset.theme || (media.matches ? 'dark' : 'light'));
  toggle?.addEventListener('click', () => setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark', true));
  media.addEventListener('change', e => { if (!storedTheme()) setTheme(e.matches ? 'dark' : 'light'); });

  const filterButtons = [...document.querySelectorAll('[data-filter]')];
  const rows = [...document.querySelectorAll('[data-post]')];
  for (const button of filterButtons) button.addEventListener('click', () => {
    filterButtons.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    const filter = button.dataset.filter;
    let count = 0;
    rows.forEach(row => { const shown = filter === 'all' || JSON.parse(row.dataset.tags).includes(filter); row.hidden = !shown; if (shown) count++; });
    const empty = document.querySelector('.filter-empty'); if (empty) empty.hidden = count > 0;
  });

  const dialog = document.querySelector('.search-dialog');
  const input = document.querySelector('#search-input');
  const results = document.querySelector('.search-results');
  const status = document.querySelector('.search-status');
  let index = null, fetching = null, failed = false;
  function renderSearch() {
    results.replaceChildren();
    if (!index) { status.textContent = failed ? '暂时无法载入文章，请关闭后重试。' : '正在载入文章…'; return; }
    const query = input.value.trim().toLocaleLowerCase();
    const terms = query.split(/\s+/).filter(Boolean);
    const matches = index.filter(p => terms.every(term => `${p.title} ${p.description} ${p.tags.join(' ')} ${p.text}`.toLocaleLowerCase().includes(term)));
    status.textContent = !query ? `全部 ${index.length} 篇文章` : matches.length ? `找到 ${matches.length} 篇文章` : '没有找到相关内容，试试其他关键词。';
    for (const post of matches) {
      const a = document.createElement('a'); a.className = 'search-result'; a.href = post.url;
      const title = document.createElement('strong'); title.textContent = post.title;
      const desc = document.createElement('p'); desc.textContent = post.description;
      const date = document.createElement('time'); date.dateTime = post.date; date.textContent = `${post.date} · ${post.tags.join(' / ')}`;
      a.append(title, desc, date); results.append(a);
    }
  }
  async function openSearch() {
    if (!dialog || dialog.open) return;
    dialog.showModal(); input.focus(); renderSearch();
    if (!index && !fetching) {
      failed = false;
      fetching = fetch(`${base}/search.json`).then(r => { if (!r.ok) throw new Error('Search unavailable'); return r.json(); }).then(data => { index = data; failed = false; }).catch(() => { failed = true; }).finally(() => { fetching = null; renderSearch(); });
    }
  }
  document.querySelector('[data-search-open]')?.addEventListener('click', openSearch);
  document.querySelector('[data-search-close]')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', e => { if (e.target !== dialog) return; const r = dialog.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close(); });
  input?.addEventListener('input', renderSearch);
  document.addEventListener('keydown', e => {
    const editing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
    if ((!editing && e.key === '/') || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) { e.preventDefault(); openSearch(); }
  });

  let toastTimer;
  function toast(message) { const box = document.querySelector('.toast'); box.textContent = message; box.classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => box.classList.remove('visible'), 2600); }
  document.querySelector('[data-copy-link]')?.addEventListener('click', async () => {
    const url = location.href.split('#')[0];
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(url);
      else {
        const area = document.createElement('textarea'); area.value = url; area.style.position = 'fixed'; area.style.opacity = '0'; document.body.append(area); area.select(); const ok = document.execCommand('copy'); area.remove(); if (!ok) throw new Error('Clipboard unavailable');
      }
      toast('文章链接已复制');
    } catch { toast('请从浏览器地址栏复制文章链接'); }
  });

  if (document.body.classList.contains('page-post')) {
    const bar = document.querySelector('.reading-progress span');
    let scheduled = false;
    function update() { const length = root.scrollHeight - innerHeight; const ratio = length > 0 ? Math.min(1, Math.max(0, scrollY / length)) : 1; bar.style.transform = `scaleX(${ratio})`; scheduled = false; }
    addEventListener('scroll', () => { if (!scheduled) { scheduled = true; requestAnimationFrame(update); } }, { passive: true });
    addEventListener('resize', update); update();
    if ('IntersectionObserver' in window) {
      const links = [...document.querySelectorAll('.toc a[href^="#section-"]')];
      const observer = new IntersectionObserver(entries => { for (const entry of entries) if (entry.isIntersecting) links.forEach(a => a.classList.toggle('active', a.hash === '#' + entry.target.id)); }, { rootMargin: '-5% 0px -70% 0px', threshold: 0 });
      document.querySelectorAll('.prose h2[id],.prose h3[id]').forEach(h => observer.observe(h));
    }
  }
})();
