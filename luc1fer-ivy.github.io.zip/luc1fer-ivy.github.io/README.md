# Jason's blog

一个参考 Chalk 阅读体验重新设计的中文个人博客。窄栏、留白、中文衬线标题、暖白底色；支持文章目录、归档、标签筛选、全文搜索、深色模式、RSS、手机屏幕和打印。

源码不依赖 Ruby、Jekyll 或 npm 安装。Markdown 解析器 Marked 17.0.5 已随仓库附带，并保留 MIT 许可证。只需要 Node.js 20 或以上；GitHub Actions 使用 Node.js 22。

## 发布到 GitHub Pages

1. 在 GitHub 账号 `luc1fer-Ivy` 下创建一个 **Public** 仓库，命名为 `luc1fer-ivy.github.io`。
2. 将本项目全部文件上传到仓库的 `main` 分支，**包括 `.github/workflows/pages.yml`**。如果浏览器上传跳过隐藏文件夹，请在 GitHub 的 Add file → Create new file 中手动创建该路径，再粘贴文件内容；也可以使用 Git 推送。
3. 进入仓库 **Settings → Pages → Build and deployment → Source**，选择 **GitHub Actions**。
4. 打开仓库 **Actions → Build and deploy blog → Run workflow**。首次未设置 Pages 导致失败时，完成第 3 步后重新运行。
5. 等待工作流成功，在 Settings → Pages 中点击 Visit site。之后每次修改 `main`，网站都会自动更新。

如果仓库叫其他名字，也能发布：工作流会自动读取 GitHub Pages 的网站根路径，处理 `/仓库名/` 前缀。不要选择“Deploy from a branch”，除非你只打算发布已经生成的 `dist` 文件。

如果使用 Git，先在 GitHub 的 `luc1fer-Ivy` 账号下创建空仓库 `luc1fer-ivy.github.io`，然后在本项目文件夹执行：

```sh
git init
git branch -M main
git add .
git commit -m "Create personal blog"
git remote add origin https://github.com/luc1fer-Ivy/luc1fer-ivy.github.io.git
git push -u origin main
```

## 修改个人资料

修改 `site.json`。`title` 是网站名字，`author` 是作者，`headline` 是首页大标题，`description` 是首页介绍。`github` 填用户名（不填完整网址），`email` 填希望公开的邮箱；留空时不显示相应入口。

`url` 在 GitHub Actions 中自动获取，不需要手动填写。若本地部署到其他主机，可设置为网站来源网址（不含子路径），例如 `https://example.com`；`baseurl` 用于可选子路径。

## 写一篇文章

在 `_posts` 文件夹新增 `2026-11-01-article-name.md`。文件名中的日期、英文短名会用于排序和文章链接；英文短名需要唯一。复制下面的格式：

```markdown
---
title: "我的文章标题"
description: "在首页显示的一句话介绍。"
tags: ["学习"]
sample: false
pinned: false
---

这里是正文。

## 一个小标题

正文支持 **加粗**、列表、链接、图片、引用、代码块和表格。
```

文章顶部的配置支持单行字符串、JSON 格式数组和布尔值；请按上例书写，不使用多行 YAML。`sample: true` 会明确标出“示例文章”，删除原示例或改为自己的内容后设为 `false`。`pinned: true` 表示首页置顶。`draft: true` 表示不生成网页、不进入搜索、归档或 RSS；公开仓库中草稿源文件仍可被看到。

新增或删除文章会同步更新首页、归档、搜索、目录、RSS 和站点地图。当前三篇文章都是明确标注的示例，不代表作者经历。

## 插入自己的照片

把适合网页展示的 JPG/WebP 图片放入 `assets/images`，在 Markdown 中写：

```markdown
![照片说明](/assets/images/my-photo.jpg)
```

构建时会自动处理 GitHub 项目网站的路径前缀。不要将相机 RAW 原片直接用于网页，建议导出压缩后的网页图片。

## 本地预览

```sh
node scripts/build.mjs
node scripts/check.mjs
python3 -m http.server 8000 --directory dist
```

打开 `http://localhost:8000`。修改源文件后重新构建并刷新。Windows 安装 Python 后可将最后一行替换为 `py -m http.server 8000 --directory dist`。

无需运行 `npm install`。`dist/` 是可独立部署的生成结果；`assets/`、`_posts/`、`scripts/` 和 `site.json` 是可维护的源码。

## 文件说明

| 文件/目录 | 用途 |
|---|---|
| `site.json` | 网站标题、作者、介绍和联系信息 |
| `_posts/` | Markdown 文章 |
| `assets/style.css` | 排版与颜色 |
| `assets/app.js` | 搜索、主题切换、标签筛选和文章交互 |
| `scripts/build.mjs` | 无需安装依赖的静态网站构建 |
| `scripts/check.mjs` | 检查生成页面的链接、锚点和元数据 |
| `.github/workflows/pages.yml` | GitHub Pages 自动发布工作流 |
| `dist/` | 已生成的完整网站 |

## 来源与许可证

本项目是独立实现，未复制参考博主的文章、照片或个人资料，不依赖原 Chalk 的旧构建工具。随附 Marked 的版权和许可见 `vendor/marked-LICENSE.md`。个人文章和照片的权利归作者所有。
