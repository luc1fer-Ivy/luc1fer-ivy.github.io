# 开启 GitHub 登录、评论和点赞

已经接入 giscus。访客在文章底部用 GitHub 登录，就能发表评论、回复和点击 👍；数据保存在你自己的 GitHub Discussions，换手机也会保留。

## 你只需开通两项

1. 打开 https://github.com/luc1fer-Ivy/luc1fer-ivy.github.io/settings 。在 General → Features 勾选 **Discussions**。如出现 Set up discussions，完成初始化。使用默认的 **Announcements** 分类即可。
2. 打开 https://github.com/apps/giscus ，点击 **Install**，选择账号 `luc1fer-Ivy`。选择 **Only select repositories**，只授权 `luc1fer-ivy.github.io`，然后安装。

这是 GitHub 官方授权界面中的第三方开源评论应用，请核对名称 giscus。网站不会索要 GitHub 密码或个人访问令牌。

代码会在 Actions 构建时自动读取仓库和分类的公开 ID。你不需要手动创建 OAuth App、准备服务器、填写 App Secret，或粘贴网页上的 script。

## 更新你现在的 GitHub Pages

你的仓库目前采用“上传一个 ZIP，再由 Actions 解压”的方式。下载这次的 `luc1fer-ivy.github.io.zip`，在仓库 **Add file → Upload files** 上传，替换原来的同名 ZIP，然后 Commit changes。文件名必须是 `luc1fer-ivy.github.io.zip`，不要带下载时自动增加的 `(1)`。

现有 `.github/workflows/pages.yml` 可以继续使用。等 Actions 变绿，打开文章，点击标题下方 **评论与点赞 ↓**。评论框里选择 **使用 GitHub 登录**，授权后可以评论；点击评论区顶部的 👍 即可点赞或取消。

本次包保留当前 GitHub ZIP 中的全部 4 篇文章和照片，包括《忧郁的神》。以后写文章仍然只需在 `_posts` 中增加 Markdown 文件。

## 管理评论

打开 https://github.com/luc1fer-Ivy/luc1fer-ivy.github.io/discussions 。每篇文章在首次有人评论或回应时生成对应讨论。你可以在 GitHub 编辑、删除不当评论，或锁定讨论。不要删除仍需保留评论的讨论。

文章使用 `post:英文短名` 作为固定标识。改文章标题、网站域名不会串评论；更改 Markdown 文件名里的英文短名，会成为新的讨论。

## 配置与故障排查

- `comments.json`：`enabled` 控制是否开启；`repo` 是保存评论的公开仓库；`category` 默认 `Announcements`。保留 `categoryId` 为空可在构建时自动识别。想固定 ID 时，可从 https://giscus.app/zh-CN 获取 `data-repo-id` / `data-category-id` 写入对应字段。
- 显示“正在开通”：确认 Discussions 已开启、giscus 已授权这个仓库，并存在名字完全相同的 Announcements 分类。
- 显示“无法连接”：点击重试，或用“在 GitHub 查看”打开讨论区；检查当前网络能否访问 GitHub 和 giscus.app。
- 刚上线的文章没有讨论是正常的：第一次评论或回应时会自动建立。
- 旧网站没有新互动区：确认同名 ZIP 已替换、Actions 最新一次成功，再刷新页面。

登录、评论、回应由 giscus 的 GitHub OAuth 和 GitHub Discussions 提供；它不是微信、QQ、X 或 Instagram 的登录入口。登录仅用于文章互动，不代表网站新增了会员中心。

## 验证

运行 `node scripts/build.mjs`、`node scripts/check.mjs` 和 `node --test scripts/comments.test.mjs`。真实授权及发布评论，须在上面两项开通、网站包上传之后，用自己的 GitHub 账号验证。
