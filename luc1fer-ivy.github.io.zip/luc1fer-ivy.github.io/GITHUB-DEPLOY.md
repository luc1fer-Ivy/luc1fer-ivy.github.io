# 发布到 luc1fer-Ivy 的 GitHub Pages

网站文件已准备好。此说明不代表 GitHub 仓库已创建或网站已上线。

- GitHub 账号：`luc1fer-Ivy`
- 仓库名称：`luc1fer-ivy.github.io`（使用小写）
- 上线后网址：`https://luc1fer-ivy.github.io/`

## 浏览器上传

1. 登录 GitHub，创建一个 Public 仓库，名称填写 `luc1fer-ivy.github.io`。
2. 解压源码包，将文件夹里的**文件本身**上传到仓库根目录，不要把最外层文件夹作为一层目录上传。
3. 确认仓库根目录包含 `site.json`、`scripts`、`vendor`、`assets`、`_posts` 和 `.github/workflows/pages.yml`。
4. 如果上传时遗漏了 `.github`，在仓库中选择 **Add file → Create new file**，文件名填写 `.github/workflows/pages.yml`，内容从源码包同名文件复制。
5. 在仓库的 **Settings → Pages → Source** 中选择 **GitHub Actions**。
6. 在 **Actions → Build and deploy blog → Run workflow** 中运行工作流。成功后在 Pages 设置里打开网站。

后续向 `main` 分支提交文章，会自动构建并更新网站。

## 使用 Git 推送

在 GitHub 创建上述空仓库后，在解压后的源码文件夹执行：

```sh
git init
git branch -M main
git add .
git commit -m "Create Jason's blog"
git remote add origin https://github.com/luc1fer-Ivy/luc1fer-ivy.github.io.git
git push -u origin main
```

然后完成上述 Pages 设置。网站构建无需安装 npm 依赖；GitHub Actions 会自动准备 Node.js。

个人资料修改 `site.json`，文章存放于 `_posts`。详细写作说明见 `README.md`。
